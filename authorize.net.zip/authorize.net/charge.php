<?php
require_once "config.php";
 
if (isset($_POST['submit'])) {
 
    try {
        $creditCard = new Omnipay\Common\CreditCard([
            'number' => $_POST['cc_number'],
            'expiryMonth' => $_POST['expiry_month'],
            'expiryYear' => $_POST['expiry_year'],
            'cvv' => $_POST['cvv'],
        ]);
 
        // Generate a unique merchant site transaction ID.
        $transactionId = rand(100000000, 999999999);
 
        $response = $gateway->authorize([
            'amount' => $_POST['amount'],
            'currency' => 'USD',
            'transactionId' => $transactionId,
            'card' => $creditCard,
        ])->send();
 
        if($response->isSuccessful()) {
 
            // Captured from the authorization response.
            $transactionReference = $response->getTransactionReference();
 
            $response = $gateway->capture([
                'amount' => $_POST['amount'],
                'currency' => 'USD',
                'transactionReference' => $transactionReference,
                ])->send();
 
            $transaction_id = $response->getTransactionReference();
            $amount = $_POST['amount'];
 
            // Insert transaction data into the database
            $isPaymentExist = $db->query("SELECT * FROM payments WHERE transaction_id = '".$transaction_id."'");
 
            if($isPaymentExist) { 
                $insert = $db->query("INSERT INTO payments(transaction_id, amount, currency, payment_status) VALUES('$transaction_id', '$amount', 'USD', 'Captured')");
            }
 
            echo "Your payment transaction id is: ". $transaction_id;
        } else {
            // not successful
            echo $response->getMessage();
        }
    } catch(Exception $e) {
        echo $e->getMessage();
    }
}