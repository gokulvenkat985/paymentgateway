<?php
require_once "vendor/autoload.php";
 
// Connect with the database 
$db = new mysqli('localhost', 'gokul', 'goodday123', 'laravel-testing');
  
if ($db->connect_errno) {
    die("Connect failed: ". $db->connect_error);
}
 
$gateway = Omnipay\Omnipay::create('AuthorizeNetApi_Api');
$gateway->setAuthName('77emXK937');
$gateway->setTransactionKey('37LyzKs3m6qpH92D');
$gateway->setTestMode(true); //comment this line when move to 'live'