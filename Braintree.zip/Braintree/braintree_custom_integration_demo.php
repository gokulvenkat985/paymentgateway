<?php
/**
 * Braintree - Payment Gateway Custom integration example
 * ==============================================================================
 * 
 * @version v1.0: braintree_custom_integration_demo.php 2016/03/25
 * @copyright Copyright (c) 2016, http://www.ilovephp.net
 * @author Sagar Deshmukh <sagarsdeshmukh91@gmail.com>
 * You are free to use, distribute, and modify this software
 * ==============================================================================
 *
 */

// Braintree library
require 'braintree/lib/Braintree.php';

$params = array(
	"testmode"   => "on",
	"merchantid" => "vny2gyv4jfy3kjyg",
	"publickey"  => "9j6ct7swjj2h9p2h",
	"privatekey" => "4c1b45a76eeab1230d28471b50695f43",
);

if ($params['testmode'] == "on")
{
	Braintree_Configuration::environment('sandbox');
}
else
{
	Braintree_Configuration::environment('production');
}

Braintree_Configuration::merchantId($params["merchantid"]);
Braintree_Configuration::publicKey($params["publickey"]);
Braintree_Configuration::privateKey($params["privatekey"]);

if(isset($_POST['make_payment']))
{
	// Customer details
	$customer_firstname   = $_POST['c_firstname'];
	$customer_lastname    = $_POST['c_lastname'];
	$customer_email       = $_POST['c_email'];
	$customer_phonenumber = $_POST['c_phonenumber'];
	// EOF Customer details

	// Customer billing details
	$firstname = $_POST['firstname'];
	$lastname  = $_POST['lastname'];
	$email     = $_POST['c_email'];
	$address1  = $_POST['address1'];
	$address2  = $_POST['address2'];
	$city      = $_POST['city'];
	$state     = $_POST['state'];
	$postcode  = $_POST['postcode'];
	$country   = $_POST['country'];
	$phone     = $_POST['c_phonenumber'];
	// EOF Customer billing details

	// Credit Card Details
	$card_number = $_POST['card_number'];
	$cvv         = $_POST['cvv'];
	$exp_date    = explode("/",$_POST['exp_date']);
	// EOF Credit Card Details

	// Create customer in braintree Vault
	$result = Braintree_Customer::create(array(
		'firstName' => $customer_firstname,
		'lastName'  => $customer_lastname,
		'phone'     => $customer_phonenumber,
		'email'     => $customer_email,
		'creditCard' => array(
			'number'          => $card_number,
			'cardholderName'  => $firstname . " " . $lastname,
			'expirationMonth' => $exp_date[0],
			'expirationYear'  => $exp_date[1],
			'cvv'             => $cvv,
			'billingAddress' => array(
				'postalCode'        => $postcode,
				'streetAddress'     => $address1,
				'extendedAddress'   => $address2,
				'locality'          => $city,
				'region'            => $state,
				'countryCodeAlpha2' => $country
			)
		)
	));

	if ($result->success) {
		// Save this Braintree_cust_id in DB and use for future transactions too
		$braintree_cust_id = $result->customer->id; 
	} else {
		die("Error : ".$result->message);
	}
	// EOF Create customer in braintree Vault

	$sale = array(
				'customerId' => $braintree_cust_id,
				'amount'   => $_POST['amount'],
				'orderId'  => $_POST['invoiceid'],
				'options' => array('submitForSettlement'   => true)
			);
						
	$result = Braintree_Transaction::sale($sale);

	if ($result->success)
	{
		// Execute on payment success event at here
	}
	else
	{
		echo "Error : ".$result->_attributes['message'];
	}
	
	echo "payment success";
  ?><html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <link href='https://fonts.googleapis.com/css?family=Lato:300,400|Montserrat:700' rel='stylesheet' type='text/css'>
  <style>
    @import url(//cdnjs.cloudflare.com/ajax/libs/normalize/3.0.1/normalize.min.css);
    @import url(//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css);
  </style>
  <link rel="stylesheet" href="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/default_thank_you.css">
  <script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/jquery-1.9.1.min.js"></script>
  <script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/html5shiv.js"></script>

</head>
<body>
  <header class="site-header" id="header">
    <h1 class="site-header__title" data-lead-id="site-header-title">THANK YOU!</h1>
  </header>

  <div class="main-content">
    <i class="fa fa-check main-content__checkmark" id="checkmark"></i>
    <p class="main-content__body" data-lead-id="main-content-body">Thanks a bunch for filling that out. It means a lot to us, just like you do! We really appreciate you giving us a moment of your time today. Thanks for being you.</p>
  </div>

  <footer class="site-footer" id="footer">
    <p class="site-footer__fineprint" id="fineprint">Copyright ©2014 | All Rights Reserved</p>
  </footer>
</body>
</html><?php exit;
}
else
if (isset($_POST['braintree_cust_id']))
{
	$sale = array(
				'customerId' => $braintree_cust_id,
				'amount'     => $_POST['amount'],
				'orderId'    => $_POST['invoiceid'],  // This field is get back in responce to track this transaction
				'options'    => array('submitForSettlement' => true)
			);
}
?>
<?php
    header("Pragma: no-cache");
    header("Cache-Control: no-cache");
    header("Expires: 0");

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}
table{
    width: 100%;
    height:100%;
    text-align: center;
}
th {
  height: 50px;
}
* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}

</style>
</head>
<body>


<div class="row">
  <div class="col-75">
    <div class="container">
     <form id="checkout" method="post" action="">

          <div class="col-50">
            <h3>Braintree Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
             <input type="hidden" name="invoiceid" value="123456">
            <label for="cname">First Name</label>
             <input id="c_firstname" name="c_firstname" class="input-field card-field" type="text" placeholder="First Name" autocomplete="off">

            <label for="ccnum">Last Name</label>
           <input id="c_lastname" name="c_lastname" class="input-field card-field" type="text" placeholder="Last Name" autocomplete="off">
            <label for="expmonth">Email</label>
           <input id="c_email" name="c_email" class="input-field card-field" type="text" placeholder="Email" autocomplete="off">
            <label for="expmonth">Phone Number</label>
             <input id="c_phonenumber" name="c_phonenumber" class="input-field card-field" type="text"placeholder="Phone Number" autocomplete="off">




             <h4 class="bt_title">Customer Billing Information</h4>
              <label for="expmonth">First Name</label>
              <input id="firstname" name="firstname" class="input-field card-field" type="text" placeholder="First Name" autocomplete="off">
              <label for="expmonth">Last Name</label>
             <input id="lastname" name="lastname" class="input-field card-field" type="text" placeholder="Last Name" autocomplete="off">
              <label for="expmonth">Address1</label>
             <input id="address1" name="address1" class="input-field card-field" type="text" placeholder="Address" autocomplete="off">
              <label for="expmonth">Address2</label>
             <input id="address2" name="address2" class="input-field card-field" type="text" placeholder="Address" autocomplete="off">
              <label for="expmonth">City/Town</label>
             <input id="city" name="city" class="input-field card-field" type="text" placeholder="City/Town" autocomplete="off">
              <label for="expmonth">State/Region</label>
             <input id="state" name="state" class="input-field card-field" type="text" placeholder="State/Region" autocomplete="off">
              <label for="expmonth">Post Code</label>
             <input id="postcode" name="postcode" class="input-field card-field" type="text" placeholder="Post Code" autocomplete="off">
              <label for="expmonth">Country</label>
             <input id="country" name="country" class="input-field card-field" type="text" placeholder="Country" autocomplete="off" value="IN">
            
            <div class="row">
              <div class="col-50">
                <table class="table table-bordered ">
    <thead style="background-color: skyblue;">
      <tr>
        <th>Card Number</th>
        <th>Expiry</th>  
        <th>CVV</th>
        <!-- <th>Password</th> -->
      </tr>
    </thead >
    <tbody style="background-color: white;">
      <tr>
        <td>4005519200000004</td>
        <td>12/2021</td>
        <td>123</td>
        <!-- <td>1221</td> -->
      </tr>
      <tr>
        <td>4111111111111111</td>
        <td>12/2021</td>
       <td>123</td>  
        <!-- <td>Test</td> -->
      </tr>
    </tbody>
  </table>
              </div>
              <div class="col-50">
                <h4 class="bt_title">Credit Card Details</h4>
                 <label for="expmonth">Card number</label>
            <input id="card_number" name="card_number" class="input-field card-field" type="text" placeholder="Card number" autocomplete="off">
            <label for="expmonth">CVV</label>
             <input id="CVV" name="cvv" class="input-field card-field" type="text" placeholder="CVV" autocomplete="off">
            <label for="expmonth">Expiration date (MM/YY)</label>
            <input id="exp_date" name="exp_date" class="input-field card-field" type="text" placeholder="Expiration date (MM/YY)" autocomplete="off">
            <label for="expmonth">Amount</label>

            <input id="amount" name="amount" class="input-field card-field form-control" type="text" inputmode="numeric" placeholder="Amount" autocomplete="off" step="any" >

                
                <input type="submit" name="make_payment" value="Make Payment" class="pay-btn btn btn-primary" id="but">
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
 
</div>

</body>
</html>
