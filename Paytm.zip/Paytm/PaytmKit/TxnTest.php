<?php
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Merchant Check Out Page</title>
<meta name="GENERATOR" content="Evrsoft First Page">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<center><h2>Merchant Check Out Page</h2><br>
<div class="card" style="width: 50rem; background-color: #b3ecff;">
  <div class="card-body">
    <form method="post" action="pgRedirect.php" class="form-group">
		 <table class="table">
    	<thead style="background-color: #0099cc; color:white;">
      <tr>
					<th>S.No</th>
					<th>Label</th>
					<th>Value</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>1</td>
					<td><label>ORDER_ID::*</label></td>
					<td><input id="ORDER_ID" tabindex="1" class="form-control" maxlength="20" size="20"
						name="ORDER_ID" autocomplete="off"
						value="<?php echo  "ORDS" . rand(10000,99999999)?>">
					</td>
				</tr>
				<tr>
					<td>2</td>
					<td><label>CUSTID ::*</label></td>
					<td><input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" class="form-control" autocomplete="off" value="CUST001"></td>
				</tr>
				<tr>
					<td>3</td>
					<td><label>INDUSTRY_TYPE_ID ::*</label></td>
					<td><input id="INDUSTRY_TYPE_ID" class="form-control" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail"></td>
				</tr>
				<tr>
					<td>4</td>
					<td><label>Channel ::*</label></td>
					<td><input id="CHANNEL_ID" tabindex="4" class="form-control" maxlength="12"
						size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
					</td>
				</tr>
				<tr>
					<td>5</td>
					<td><label>txnAmount*</label></td>
					<td><input title="TXN_AMOUNT" class="form-control" tabindex="10"
						type="text" name="TXN_AMOUNT"
						value="1">
					</td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td><input value="CheckOut" type="submit" class="btn btn-primary" 	onclick=""></td>
				</tr>
			</tbody>
		</table>
		<center><!-- <pre>* - Mandatory Fields(Test Card details)

Test Mobile number:7777777777.
OTP             : 489871. 
		</pre> --></center>
	</form>

  </div>
  <br>
  <table class="table table-bordered">
    <thead  style="background-color: #0099cc; color: white;">
      <tr>
        <th>Test Card Details</th>
        <th>Expiry</th>  
        <th>CVV</th>
        <th>Name</th>
      </tr>
    </thead>
    <tbody style="background-color: white;">
      <tr>
        <td>4444 3333 2222 1111</td>
        <td>07/23</td>
        <td>123</td>
        <td>Test</td>
      </tr>
      <tr>
        <td>4111 1111 1111 1111</td>
        <td>07/23</td>
       <td>123</td>  
        <td>Test</td>
      </tr>
    </tbody>
  </table>
</div>

</center>
	
</body>
</html>