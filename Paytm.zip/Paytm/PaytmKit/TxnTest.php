<?php
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}
table{
    width: 100%;
    height:100%;
    text-align: center;
}
th {
  height: 50px;
}
* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
</head>
<body>


<div class="row">
  <div class="col-75">
    <div class="container">
      <form method="post" action="pgRedirect.php" class="form-group">

          <div class="col-50">
            <h3>Paytm Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">ORDER_ID::*</label>
            <input id="ORDER_ID"  type="text" class="form-control" 
						name="ORDER_ID" autocomplete="off"
						value="<?php echo  "ORDS" . rand(10000,99999999)?>">
            <label for="ccnum">CUSTID ::*</label>
            <input id="CUST_ID" type="text" tabindex="2"  name="CUST_ID" class="form-control" autocomplete="off" value="CUST001">
            <label for="expmonth">INDUSTRY_TYPE_ID ::*</label>
           <input id="INDUSTRY_TYPE_ID" type="text" class="form-control" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail">
            <label for="expmonth">Channel ::*</label>
            <input id="CHANNEL_ID" tabindex="4" type="text" class="form-control" 
						 name="CHANNEL_ID" autocomplete="off" value="WEB">

            
            <div class="row">
              <div class="col-50">
                <table class="table table-bordered ">
    <thead style="background-color: skyblue;">
      <tr>
        <th>Card Number</th>
        <th>Expiry</th>  
        <th>CVV</th>
        <!-- <th>Password</th> -->
      </tr>
    </thead >
    <tbody style="background-color: white;">
      <tr>
        <td>4242 4242 4242 4242</td>
        <td>07/23</td>
        <td>111</td>
        <!-- <td>1221</td> -->
      </tr>
      <tr>
        <td>4111 1111 1111 1111</td>
        <td>07/23</td>
       <td>123</td>  
        <!-- <td>Test</td> -->
      </tr>
    </tbody>
  </table>
              </div>
              <div class="col-50">

                 <label for="expmonth">TxnAmount*</label>
            <input title="TXN_AMOUNT" class="form-control" tabindex="10"
						type="text" name="TXN_AMOUNT"
						value="1">
                <input value="CheckOut" type="submit" class="btn btn-primary" 	onclick="">
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
 
</div>

</body>
</html>
