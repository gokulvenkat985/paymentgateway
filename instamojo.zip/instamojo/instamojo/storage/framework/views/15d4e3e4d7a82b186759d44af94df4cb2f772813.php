<link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>" />
<script src="https://js.stripe.com/v3/"></script>
<form action="<?php echo e(url('charge')); ?>" method="post" id="payment-form">
    <div class="form-row">
        <p><input type="text" name="amount" placeholder="Enter Amount" /></p>
        <p><input type="email" name="email" placeholder="Enter Email" /></p>
        <label for="card-element">
        Credit or debit card
        </label>
        <div id="card-element">
        <!-- A Stripe Element will be inserted here. -->
        </div>
     
        <!-- Used to display form errors. -->
        <div id="card-errors" role="alert"></div>
    </div>
    <button>Submit Payment</button>
    <?php echo e(csrf_field()); ?>

</form>
<script>
var publishable_key = '<?php echo e(env('STRIPE_PUBLISHABLE_KEY')); ?>';
</script>
<script src="<?php echo e(asset('/js/card.js')); ?>"></script><?php /**PATH /var/www/html/blog/resources/views/payment.blade.php ENDPATH**/ ?>