<!-- <!DOCTY --><!-- PE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Instamojo Payment Gateway Integrate - Tutsmake.com</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
    <style>
       button{
        margin-bottom: 12px;
       }
       #cards{
        margin-top: 40px;
        /*margin-bottom: 2px: */
        background-color: #b3ffb3;
       }
      
    </style>
</head>
<body >

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Opps!</strong> Something went wrong<br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> 

<center >
    <div class="card" id="cards"style="width:40rem;">
  <div class="card-body"><br>
    <h4 class="card-title ">Payment details</h4>
    <form  action="<?php echo e(url('pay')); ?>" method="POST" name="laravel_instamojo">
    <?php echo e(csrf_field()); ?>

    <div class="col-md-12">
            <div class="form-group">
                <strong style="float: left;">Name</strong>
                <input type="text" name="name" class="form-control" placeholder="Enter Name" required>
            </div>
        </div>
    <div class="col-md-12">
            <div class="form-group">
                <strong style="float: left;">mobile</strong>
                 <input type="text" name="mobile_number" class="form-control" placeholder="Enter Mobile Number" required>
            </div>
        </div>
    <div class="col-md-12">
            <div class="form-group">
                <strong style="float: left;">email Number</strong>
                <input type="text" name="email" class="form-control" placeholder="Enter Email id" required>
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <strong style="float: left;">Event Fees</strong>
                <input type="text" name="amount" class="form-control" placeholder="" value="100" readonly="">
            </div>
        </div>
    
       <button type="submit" class="btn btn-primary mb-5">Submit</button>
          </form>
  </div>
</div>
  <div class="card" style="width:40rem;">
  <div class="card-body">
<table class="table table-bordered ">
    <thead style="background-color: skyblue;">
      <tr>
        <th>Test Card details</th>
        <th>Expiry</th>  
        <th>CVV</th>
        <th>Password</th>
      </tr>
    </thead >
    <tbody style="background-color: white;">
      <tr>
        <td>4242 4242 4242 4242</td>
        <td>07/23</td>
        <td>111</td>
        <td>1221</td>
      </tr> -->
      <!-- <tr>
        <td>4111 1111 1111 1111</td>
        <td>07/23</td>
       <td>123</td>  
        <td>Test</td>
      </tr> -->
    <!-- </tbody>
  </table>
</div>
</div> -->

<!-- <pre>* - Mandatory Fields(Test Card details)

Number: 4242 4242 4242 4242.
Date: Any valid future date.
CVV: 111.
Name: abc.
password:1221
        </pre> -->


 <!-- 
</center> -->



     
<!-- </body> -->
</html>
<center >
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}
table{
    width: 100%;
    height:100%;
    text-align: center;
}
th {
  height: 50px;
}
* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
</head>
<body>


<div class="row">
  <div class="col-75">
    <div class="container">
     <form  action="<?php echo e(url('pay')); ?>" method="POST" name="laravel_instamojo">
  <?php echo e(csrf_field()); ?>

          <div class="col-50" >
           
            <h3> Instamojo Payment</h3>
     
            <label for="cname" style="float: left;">Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Name" required>
            <label for="ccnum" style="float: left;">Mobile number</label>
           <input type="text" name="mobile_number" class="form-control" placeholder="Enter Mobile Number" required>
            <label for="expmonth" style="float: left;">Email</label>
            <input type="text" name="email" class="form-control" placeholder="Enter Email id" required>
            <div class="row">
              <div class="col-50">
                
                <table class="table table-bordered ">
    <thead style="background-color: skyblue;">
      <tr>
        <th>Card Details</th>
        <th>Expiry</th>  
        <th>CVV</th>
        <th>Password</th>
      </tr>
    </thead >
    <tbody style="background-color: white;">
      <tr>
        <td>4242 4242 4242 4242</td>
        <td>07/23</td>
        <td>111</td>
        <td>1221</td>
      </tr>
      <tr>
        <td>4111 1111 1111 1111</td>
        <td>07/23</td>
       <td>123</td>  
        <td>1221</td>
      </tr>
    </tbody>
  </table>
              </div>
              <div class="col-50">

                <label for="cvv" style="float: left;">Entry Fee</label>
                  <input type="text" name="amount" class="form-control" placeholder="" value="100" readonly="">
               <button type="submit" class="btn btn-primary mb-5">Checkout</button>
              </div>
            </div>
          </div>
          
        </div>

      </form>
    </div>
  </div>
 
</div>

</body>
</html>
    <?php /**PATH /var/www/html/completed/instamojo/instamojo/resources/views/welcome.blade.php ENDPATH**/ ?>